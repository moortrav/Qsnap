%QR update algorithm when adding an extra row
%INPUTS:
%Q - Previous value of Q, n x p
%R - Previous value of R, p x p
%v - Added row, 1 x p
%OUTPUTS:
%Q - New value of Q
%R - New value of R
%u - Column removed from Q in final step (used in Qsnap update algorithm)
function [Q,R,u] = qrRow(Q,R,v)
    R = [v;R];
    Q = [zeros(size(Q,1),1),Q];
    Q = [zeros(1,size(Q,2));Q];
    Q(1,1) = 1;
    
    for i=1:size(R,2)
        [c,s] = givens(R(i,i),R(i+1,i));
        R([i,i+1],i:end) = [c,-s;s,c] * R([i,i+1],i:end);
        Q(:,[i,i+1]) = Q(:,[i,i+1])*[c,s;-s,c];
    end
    u = Q(:,end);
    R = R(1:(end-1),:);
    Q = Q(:,1:(end-1));
end