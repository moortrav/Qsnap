function n=PlotRegions(P)
    PlotRegions1(P);
end
function n = PlotRegions1(P)
    %Read in covariate tiff, get info data
    [C,S] = geotiffread("../Data/Climate/Evap_2001");
    info = geotiffinfo("../Data/Climate/Evap_2001");
    
    %Create locations from info data
    s1 = size(C,1);
    s2 = size(C,2);
    ids = zeros(s1*s2,2);
    for i=1:s2
        for j=1:s1
            idx = j+(i-1)*(s1);
            ids(idx,:) = [j,i];
        end
    end
    [lon,lat] = pix2map(info.RefMatrix, ids(:,1), ids(:,2));
    L = [lat,lon];
    %Translate locations in P with matrix coordinates
    [x,y] = map2pix(info.RefMatrix,P(:,2),P(:,1));
    x=round(x);
    y=round(y);
    
    %Read in drought tiff, convert to correct size
    [V,S] = geotiffread("../Data/Climate/SPEI_2001");
    info = geotiffinfo("../Data/Climate/SPEI_2001");
    T = condenseLoc(L,V,info);
    
    
    %Create color map matrix and plot.
    M = ones(size(C));
    M(T(:)==0)=0;
    
    for i=1:length(x)
        M(x(i),y(i)) = 2;
    end
    im = image(M);
    im.CDataMapping = 'scaled';
    map = [1,1,1;.2,1,.2;1,.2,.2];
    colormap(map);
    caxis([0,2]);
end

function n = PlotRegions2(P)
    map = imread("../Results/Climate/USA2.png");
    sz = [size(map,1),size(map,2)];
   
    %Get covariate data to determine matrix size
    [C,S] = geotiffread("../Data/Climate/Evap_2001");
    info = geotiffinfo("../Data/Climate/Evap_2001");
    
    %Resize background map image
    %map = imresize(map,size(C));
    
    %Convert lat/lon locations into matrix indicies
    R = makerefmat(-125, 50, (125-65)/size(C,2), -25/size(C,1));
    [x,y] = latlon2pix(info.RefMatrix,P(:,1),P(:,2));
    %[x,y] = map2pix(info.RefMatrix,P(:,2),P(:,1));
    x=round(x);
    y=round(y);
    
    %Change indicies in image to bright red.
    M = zeros(size(C,1),size(C,2),3);
    for i=1:length(x)
        M(x(i),y(i),:) = [255,0,0];
    end
    
    M = imresize(M,sz);
    map = map+uint8(M);
    %Plot image
    image(map);
end

function M = condenseLoc(L,V,info)
    s1 = size(V,1);
    s2 = size(V,2);
    ids = zeros(s1*s2,2);
    for i=1:s2
        for j=1:s1
            idx = j+(i-1)*(s1);
            ids(idx,:) = [j,i];
        end
    end
    [lon,lat] = pix2map(info.RefMatrix, ids(:,1), ids(:,2));
    marg = (L(1,1)-L(2,1))/2;
    M = zeros(size(L,1),1);
    for i=1:size(L,1)
        l1 = L(i,1);
        l2 = L(i,2);
        I = lat<=(l1+marg) & lat > (l1-marg) & lon <= (l2+marg) & lon > (l2-marg);
        val = sum(V(I))/sum(I);
        M(i) = val;
    end
end
