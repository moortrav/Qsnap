function [max_t, loc, PS, b_ids] = GeneralScan(X1,Y1,L1,X2,Y2,L2,tau,Gu,Gs,ms,min_size,p_meth)
    if nargin < 12
        p_meth = 1;
    end
    alpha = .01;
    max_size = min(ms,length(Y2));
    
    PS=[];
    
    SA = zeros(0,size(L2,2)+3);
    loc = zeros(1,size(L2,2)+1);

    %1 Fit regression model to dataset 1
    [beta,~,~,~,stats] = regress(Y1,X1);
    var = stats(4);
    
    %2 Calculate p-values for dataset 2
    if p_meth == 1
        Pv = pvals_non_param(X1,Y1,X2,Y2,tau);
    else
        Pv = pvals(X2,Y2,beta,var);
    end
    
    
    %3 Perform expanding circle scans on p-values, keeping track of
    %significant regions.
    
    %setup start locations
    c_num = 20;
    max_d = max(L2,[],1);
    min_d = min(L2,[],1);
    C = zeros(c_num^length(max_d),length(max_d));
    for i=1:c_num
        range = ((i-1)*c_num+1):(i*c_num);
        C(range,:) = [(1:c_num)',ones(c_num,1)*i];
    end
    C = C .* (max_d-min_d)/c_num;
    C = C + min_d;
    
    %Do spatial search for different start points
    max_t = 0;
    for i=1:size(C,1)
        start = C(i,:);
        D = sqrt(sum((L2-start).^2,2));
        [d,ids] = sort(D);
        if d(1) > .5
            continue;
        end
        
        ids = ids(1:max_size,:);
        [t,id,ts] = GenLoop(Pv,ids,tau,min_size);
        dist = D(ids(ts(:,1)));
        ps = chi2cdf(ts(:,2),1,'upper');
        S = zeros(length(dist),2);
        for f=1:length(dist)
            S(f,:) = start;
        end
        PS = [PS;[S,dist,ps]];
        if t>max_t
            max_t = t;
            radius = max(D(ids(1:id)));
            loc = [start,radius];
            b_ids = ids(1:id);
        end
        p = evcdf(-t,-Gu,Gs);
        if p < alpha
            radius = max(D(ids(1:id)));
            hs = [start,radius,p,t];
            SA = [SA;hs];
            
        end
    end
    %c_ids = c_ids - length(Y1);
    [d,id] = sort(SA(:,end),'descend');
    SA = SA(id,:);
    
    [d,id] = sort(PS(:,end));
    PS = PS(id,:);
    bonfer = 1;
    if bonfer == 1
        bon = alpha/size(PS,1);
        PS = PS(PS(:,4)<bon,:);
    else
        K = (1:size(PS,1))*alpha/size(PS,1);
        C = 1./(1:size(PS,1));
        for i=2:length(C)
            C(i) = C(i)+C(i-1);
        end
        for i=size(PS,1):-1:1
            if PS(i,4) <= K(i)/C(i)%alpha/(size(PS,1)-i+1)%
                PS = PS(1:i,:);
                break;
            end
        end
    end
    if size(PS,1)>0
        PS = sortrows(PS,[1,2,3]);
    end
    nPS = [];
    for i=1:size(PS,1)
        if i==size(PS,1)
            nPS = [nPS;PS(i,:)];
            break;
        end
        if sum(PS(i,1:2)==PS(i+1,1:2)) < 2
            nPS = [nPS;PS(i,:)];
        end
    end
    PS = nPS;
    if size(PS,1)>0
        PS = sortrows(PS,4);
    end
end

function [max_t,id,TS] = GenLoop(Pv,ids,alpha,min_size)
    max_t = 0;
    range = -.19:.01:.09;
    alphas = alpha+range;
    
    TS = zeros(size(ids,1)-min_size,2);
    
    %initialize for minimum size region
    N = min_size;
    Na = alphas*0;
    for i=1:min_size
        Na = Na + (Pv(ids(i)) < alphas);
    end
    
    %Calculate incremental test statistic
    for i=(min_size+1):length(ids)
        N = N+1;
        Na = Na + (Pv(ids(i)) < alphas);
        a = Na/N;
        den = 2*alphas.*(1-alphas);
        T = N*(a-alphas).^2./(den);
        
        [T,id] = max(T);
        %One sided variant
        %if a(id) < alphas(id)
        %    T = 0;
        %end
        
        TS(i-min_size,:) = [i,T];
        if T > max_t
            max_t = T;
            id = i;
        end
    end
end


function p = pvals(X2,Y2,beta,var)
    std = sqrt(var);
    p = Y2*0;
    for i=1:length(Y2)
        mu = X2(i,:)*beta;
        p(i) = normcdf(Y2(i),mu,std);
    end
end

function p = pvals_non_param(X1,Y1,X2,Y2,tau)
    beta = qrsimplex(X1,Y1,tau);
    p = Y2*0;
    R = Y2 - X2*beta;
    
    for i = 1:length(p)
        p(i) = sum(R < R(i))/length(R);
    end
end