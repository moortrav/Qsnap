%Naive implementation of Qsnap
%INPUTS:
%X1 - Covariates from snapshot 1
%Y1 - Responses from snapshot 1
%L1 - Locations from snapshot 1
%X2, Y2, L2 - Covariates, responses, and locations from snapshot 2
%tau - quantile to compare, [0,1]
%Gu, Gs - Parameters for gumbel distribution for p-value correction
%ms - Maximum region size
function [max_t,loc,SA] = RankTestTimeSlow(X1,Y1,L1,X2,Y2,L2,tau,Gu,Gs)
    alpha = .05;
    min_size = 20;
    max_size = 750;
    X = [X1;X2];
    Y = [Y1;Y2];
    L = [L1;L2];
    I = [ones(length(Y1),1);2*ones(length(Y2),1)];
    
    SA = zeros(0,size(L,2)+2);
    loc = zeros(1,size(L,2)+1);
    
    %[beta,hid] = qrsimplex(X,Y,tau);
    
    %setup start locations
    c_num = 20;
    max_d = max(L,[],1);
    min_d = min(L,[],1);
    C = zeros(c_num^length(max_d),length(max_d));
    for i=1:c_num
        range = ((i-1)*c_num+1):(i*c_num);
        C(range,:) = [(1:c_num)',ones(c_num,1)*i];
    end
    C = C .* (max_d-min_d)/c_num;
    C = C + min_d;
    
    %Do spatial search for different start points
    max_t = 0;
    for i=1:size(C,1)
        if i==233
            flag = 1;
        end
        start = C(i,:);
        D = sqrt(sum((L-start).^2,2));
        [d,s] = sort(D);
        num1=0;
        num2=0;
        val = 0;
        while(num1 < min_size || num2 < min_size)
            val = val+1;
            if(I(s(val)) == 1)
                num1 = num1+1;
            else
                num2 = num2+1;
            end
        end
        ids = [I(s),s];
        ids = ids(1:max_size,:);
        [t,id] = TimeLoop(X,Y,ids,tau,val);
        if t>max_t
            max_t = t;
            radius = max(D(ids(1:id,2)));
            loc = [start,radius];
        end
        p = evcdf(-t,-Gu,Gs);
        if p < alpha
            radius = max(D(ids(1:id,2)));
            hs = [start,radius,p];
            SA = [SA;hs];
            
        end
    end
    %c_ids = c_ids - length(Y1);
end

%X,Y have all data points.  ids(:,1) says which time slice they come from.
%ids is an nx2 matrix.  First column is 1 or 2, indicating which X set
%min_size is calculated so that that point in ids will have enough points
%in X2 and outside of X2.
function [best_t,best_id] = TimeLoop(X,Y,ids,tau,min_size)
    best_t = 0;
    best_id = 0;
    p = size(X,2);

    %Initialize X2
    X2 = X(ids((min_size-1):-1:1,2),:);
    X2(ids((min_size-1):-1:1,1) == 1,:) = zeros(sum(ids((min_size-1):-1:1,1)==1),p);

    %fit initial beta and b
    %Y1 = Y(ids((min_size-1):-1:1,2));
    %[beta,hid] = qrsimplex(X1,Y1,tau);
    %b=RankValues(Xc,Yc,beta,tau);
    
    %calculate T
    for i=min_size:size(ids,1)
        X1 = X(ids(i:-1:1,2),:);
        Y1 = Y(ids(i:-1:1,2));
        
        x = X(ids(i,2),:);
        v = x;
        if ids(i,1) == 1
            v = zeros(size(x));
        end
        
        %Update X2 and H
        X2 = [v;X2];
        H = X1*((X1'*X1)\X1');
        Z = X2-H*X2;
        
        [beta,hid,d] = qrsimplex(X1,Y1,tau);

        %Faster rank value update
        b = zeros(size(Y1));
        b(Y1 - X1*beta > 0) = 1;
        b(hid) = d+(1-tau);
        
        %Calculate T
        T = b'*Z*((Z'*Z)\Z'*b);
        T = T/(tau*(1-tau));
        if T > best_t
            best_t = T;
            best_id = i;
        end
    end
end
