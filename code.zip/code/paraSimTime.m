%Data simulator code.  Creates a snapshot dataset for the given parameters
%INPUTS:
%n - number of data points for each snapshot
%p - number of covariates for each snapshot
%beta - parameter vector to use for generating distribution
%type - type of error distribution to use.  Should be in {1,2,3}
%       1: Normal error
%       2: Exponential error
%       3: Uniform error
%num - Size of target region in snapshot 2 (number of points)
%tau - Center of distribution change in target area, [0,1]
function [X1,Y1,L1,X2,Y2,L2,T2] = paraSimTime(n,p,beta,type,num,tau)
    minx = -10;
    maxx = 10;

    range = .1;

    %Create uniform random L locations
    L1 = 100*rand(n,2);
    L2 = 100*rand(n,2);
    %Create uniform random X covariates
    X1 = (maxx-minx)*rand(n,p+1)+minx;
    X1(:,1) = 1;
    X2 = (maxx-minx)*rand(n,p+1)+minx;
    X2(:,1) = 1;

    %pick a hotspot center, select num points closest to it
    center = ceil(rand(1)*n);
    D = sqrt(sum((L2-L2(center,:)).^2,2));
    [d,ids] = sort(D);
    T2 = zeros(n,1);
    T2(ids(1:num))=1;
    
    %Generate Y values using parametric noise distribution
    Y1 = X1 * beta;
    Y2 = X2 * beta;
    
    qs = rand(n,1);
    ids = abs(qs-tau) < range;
    T2(~ids) = 0;
    

    offset = 5*rand(p+1,1)-1;
    offset = sqrt(p)*offset / sqrt(offset' * offset);

    
    
    %offset change
    Y2(T2==1) = X2(T2==1,:)*(beta+offset);
    
    if type == 1 % Normal
        Y1 = Y1 + normrnd(0,10,n,1);
        Y2 = Y2 + norminv(qs,0,10);
    elseif type == 2%Exponential
            Y1 = Y1 + exprnd(10,n,1);
            Y2 = Y2 + expinv(qs,10);
    elseif type == 3 %uniform
            Y1 = Y1 + 100*rand(n,1)-50;
            Y2 = Y2 + 100*qs-50;
    end
                
    
    
end