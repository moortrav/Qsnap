%Perform simulation to calculate gumbel parameters
function [u,s] = Gumbel(reps,sz,n,p)
    X = zeros(reps,1);
    for j=1:reps
        V = zeros(n,1);
        for i=1:n
            vals = zeros(sz,1);
            val = chi2rnd(p,1,1);
            w=40;
            inc = chi2rnd(p,sz,1); 
            for k = 1:sz
                vals(k) = (w*val+inc(k))/(w+1);
                w = w+1;
                val = vals(k);
            end
            V(i) = max(vals);
        end
        X(j) = max(V);
    end
    xb = sum(X)/reps;
    st = std(X);
    s = st*sqrt(6)/pi;
    u = xb - .5772*s;
end