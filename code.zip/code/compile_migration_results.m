%Combines individual regions found by search algorithms into a single excel
%sheet.
%Regions are read from output files in "migration_results".
%Excel sheet is written in the same directory.
%INPUTS:
%tau - What tau was used for the migration search.
%sz - The size of the snapshot windows (in days) for the search.
%OUTPUTS:
%R - Matrix containing bounding boxes and p-values for regions found for
%each algorithm.  Each row of R is for one snapshot pair.
%The first 5 columns are for TESS, the next 5 are for SSS-Moods, the last 5
%are for Qsnap.
%The first 4 columns for each algorithm are the bounding box cooridinates,
%by latitude and longitude, for the region found.
function R = compile_migration_results(tau,sz)
    ws = 2:6;
    R = zeros(length(ws),5*3);
    id = 1;
    for w=ws
        sfile = strcat("migrate_results/w_",int2str(w),"_tau_",int2str(tau*100),"_sz_",int2str(sz));
        M = load(sfile);
        M = M.best_areas;
        R(id,:) = [M(1,:),M(2,:),M(3,:)];
        id = id+1;
    end
    csvwrite(strcat("migrate_results/Full_tau_",int2str(tau*100),"_sz_",int2str(sz),".csv"),R);
end