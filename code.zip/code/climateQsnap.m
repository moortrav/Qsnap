function [R,q_ids,t_ids,m_ids,SAQ,SAT,SAM] = climateQsnap(tau)
%function [T1,T2,L,X1,X2,Y1,Y2] = climateQsnap()
    %[T1,T2,L,X1,X2,Y1,Y2] = process("2001.tif","2007.tif");
    D = load("ClimateData1v7.mat");
    T1 = D.T1;
    T2 = D.T2;
    L = D.L;
    X1 = D.X1;
    X2 = D.X2;
    Y1 = D.Y1;
    Y2 = D.Y2;
    
    Z1 = Y1;
    Z2 = Y2;
    Y1 = X1(:,5);
    Y2 = X2(:,5);
    X1(:,5) = Z1;
    X2(:,5) = Z2;
    %If processing takes awhile, save result and load when necessary
    
    [R,q_ids,t_ids,m_ids,SAQ,SAT,SAM] = run(T1,T2,L,X1,X2,Y1,Y2,tau);


end

function [C1,C2] = corrAnalysis(X1,X2,Y1,Y2,T1,T2)
    tids = T1 ~=0 & ~isnan(T1);
    T1 = T1(tids);
    T2 = T2(tids);
    X1 = X1(tids,:);
    X2 = X2(tids,:);
    Y1 = Y1(tids,:);
    Y2 = Y2(tids,:);
    X1 = center(X1);
    X2 = center(X2);
    Y1 = center(Y1);
    Y2 = center(Y2);
    
    %T1 = X1(:,5);
    %T2 = X2(:,5);
    
    C1 = zeros(5,size(X1,2)+1);
    C2 = zeros(5,size(X1,2)+1);
    
    for i=1:size(X1,2)
        C1(1,i) = corr(X1(:,i),T1);
        C1(2,i) = qcor(X1(:,i),T1,.1);
        C1(3,i) = qcor(X1(:,i),T1,.25);
        C1(4,i) = qcor(X1(:,i),T1,.75);
        C1(5,i) = qcor(X1(:,i),T1,.9);
        
        C2(1,i) = corr(X2(:,i),T2);
        C2(2,i) = qcor(X2(:,i),T2,.1);
        C2(3,i) = qcor(X2(:,i),T2,.25);
        C2(4,i) = qcor(X2(:,i),T2,.75);
        C2(5,i) = qcor(X2(:,i),T2,.9);
    end
    p = size(C1,2);
    C1(1,p) = corr(Y1,T1);
    C1(2,p) = qcor(Y1,T1,.1);
    C1(3,p) = qcor(Y1,T1,.25);
    C1(4,p) = qcor(Y1,T1,.75);
    C1(5,p) = qcor(Y1,T1,.9);
    
    C2(1,p) = corr(Y2,T2);
    C2(2,p) = qcor(Y2,T2,.1);
    C2(3,p) = qcor(Y2,T2,.25);
    C2(4,p) = qcor(Y2,T2,.75);
    C2(5,p) = qcor(Y2,T2,.9);
end

function q = qcor(X,Y,tau)
    p_Q = quantile(X,tau);
    Q = tau*ones(size(X));
    Q(X <= p_Q) = tau-1;
    
    mean = sum(Y)/length(Y);
    Z = Y-mean;
    var = sum(Z.^2)/length(Y);
    
    corr_sd = sqrt((tau-tau^2)*var);
    q = (Q'*Z)/(length(X)*corr_sd);
end

function [T1,T2,L,X1,X2,Y1,Y2] = process(t1,t2)
    dir = "../Data/Climate/";
    %Load individual feature files, for each time stamp
    %Combine into X and Y matricies
    info = geotiffinfo(dir+"Precip_"+t1);
    vars = ["Evap_","Humid_","MaxTemp_","MeanTemp_","Precip_"];
    resp = "Soil5cm_";
    verif = "SPEI_";
    X1=[];
    X2=[];
    for v=1:length(vars)
        [V1,S] = geotiffread(dir+vars(v)+t1);
        [V2,S] = geotiffread(dir+vars(v)+t2);
        X1 = [X1,V1(:)];
        X2 = [X2,V2(:)];
    end
    [V1,S] = geotiffread(dir+resp+t1);
    [V2,S] = geotiffread(dir+resp+t2);
    s1 = size(V1,1);
    s2 = size(V1,2);
    ids = zeros(s1*s2,2);
    for i=1:s2
        for j=1:s1
            idx = j+(i-1)*(s1);
            ids(idx,:) = [j,i];
        end
    end
    Y1 = V1(:);
    Y2 = V2(:);
    kp = Y1~=0 | Y2 ~=0 | X1(:,1) ~= 0 | X2(:,1) ~= 0;
    Y1 = Y1(kp);
    Y2 = Y2(kp);
    X1 = X1(kp,:);
    X2 = X2(kp,:);
    
    %Get locations for each pixel, Combine into L matrix
    [lon,lat] = pix2map(info.RefMatrix, ids(:,1), ids(:,2));
    L = [lat,lon];
    %Load verification files for each time stamp
    [V1,S] = geotiffread(dir+verif+t1);
    [V2,S] = geotiffread(dir+verif+t2);
    info = geotiffinfo(dir+verif+t1);
    %Convert to same scale as feature files
    T1 = condenseLoc(L,V1,info);
    T2 = condenseLoc(L,V2,info);
    L = L(kp,:);
    T1 = T1(kp);
    T2 = T2(kp);
    %T1 = convIdx([s1,s2],size(V1),ids(:,1),ids(:,2),V1);
    %T2 = convIdx([s1,s2],size(V2),ids(:,1),ids(:,2),V2);
    %Combine all data into D matrix
    D1 = [T1,L,X1,Y1]; 
    D2 = [T2,L,X2,Y2]; 
end


function M = convIdx(sz1,sz2,x,y,V)
    xmul = sz2(1)/sz1(1);
    ymul = sz2(2)/sz1(2);
    M = zeros(length(x),1);
    for i=1:length(x)
        xr = round([xmul*(x(i)-1)+1,xmul*x(i)]);
        yr = round([ymul*(y(i)-1)+1,ymul*y(i)]);
        vc = V(xr(1):xr(2),yr(1):yr(2));
        val = sum(sum(vc))/(size(vc,1)*size(vc,2));
        M(i)=val;
    end
end

function M = condenseLoc(L,V,info)
    s1 = size(V,1);
    s2 = size(V,2);
    ids = zeros(s1*s2,2);
    for i=1:s2
        for j=1:s1
            idx = j+(i-1)*(s1);
            ids(idx,:) = [j,i];
        end
    end
    [lon,lat] = pix2map(info.RefMatrix, ids(:,1), ids(:,2));
    marg = (L(1,1)-L(2,1))/2;
    M = zeros(size(L,1),1);
    for i=1:size(L,1)
        l1 = L(i,1);
        l2 = L(i,2);
        I = lat<=(l1+marg) & lat > (l1-marg) & lon <= (l2+marg) & lon > (l2-marg);
        val = sum(V(I))/sum(I);
        M(i) = val;
    end
end

function [R,q_ids,t_ids,m_ids,SAQ,SAT,SAM] = run(T1,T2,L,X1,X2,Y1,Y2,tau)
    ms = 200;%1500;
    min_sz = 20;
    
    tids = T1 ~=0 & ~isnan(T1);
    T1 = T1(tids);
    T2 = T2(tids);
    L = L(tids,:);
    X1 = X1(tids,:);
    X2 = X2(tids,:);
    Y1 = Y1(tids,:);
    Y2 = Y2(tids,:);
    
    X1 = center(X1);
    X2 = center(X2);
    Y1 = center(Y1);
    Y2 = center(Y2);
    
    X1=[ones(size(X1,1),1),X1(:,[1,2,3,4,5])];
    X2=[ones(size(X2,1),1),X2(:,[1,2,3,4,5])];
    
    %Calculate Gumbel distribution
    gr = 200;
    gs = ms-min_sz;%size(X,1) - 4*size(X,2);
    gn = 20^2;
    [Gu,Gs] = Gumbel(gr,gs,gn,size(X1,2));
    [MGu,MGs] = Gumbel(gr,gs,gn,2);
    

    %Run Qsnap on datasets
    [max_t,loc,SAQ,q_ids] = RankTestTime(X1,Y1,L,X2,Y2,L,tau,Gu,Gs,ms,min_sz);
    ids = inArea(L,SAQ);
    q_ids = L(ids==1,:);
    
    %Run TESS on datasets
    [TGu,TGs] = GumbelGenScan(200,X1,Y1,L,X2,Y2,L,tau,ms/2,min_sz);
    [max_t, loc, SAT, t_ids] = GeneralScan(X1,Y1,L,X2,Y2,L,tau,TGu,TGs,ms/2,min_sz);
    ids = inArea(L,SAT);
    t_ids = L(ids==1,:);
    
    %Run SSS-Moods on datasets
    [max_t,loc,SAM,m_ids] = MoodsTime(X1,Y1,L,X2,Y2,L,tau,MGu,MGs,ms,min_sz);
    m_ids2 = m_ids(m_ids > length(X1))-length(X1);
    ids = inArea(L,SAM);
    m_ids = L(ids==1,:);
    
    
    
    
    
    
    
    
    %Evaluate regions found
    R = zeros(4,3);
    %del = T2-T1;
    %R(2,1) = sum(del(q_ids))/length(q_ids);
    %R(1,1) = sum(T2(q_ids))/length(q_ids);
    %R(2,2) = sum(del(t_ids))/length(t_ids);
    %R(1,2) = sum(T2(t_ids))/length(t_ids);
    %R(2,3) = sum(del(m_ids))/length(m_ids);
    %R(1,3) = sum(T2(m_ids))/length(m_ids);
    
    %Evalate for all regions found, on average
    %T1=Y1;
    %T2=Y2;
    [R(:,1),QA] = eval_area(T1,T2,L,SAQ,tau,X1,X2);
    [R(:,2),TA] = eval_area(T1,T2,L,SAT,tau,X1,X2);
    [R(:,3),MA] = eval_area(T1,T2,L,SAM,tau,X1,X2);
    [~,p1] = ttest2(QA,TA);
    [~,p2] = ttest2(QA,MA);
    [~,p3] = ttest2(MA,TA);
    TT = [p1,p2,p3]
end

function ids = inArea(L,SA)
    ids = zeros(size(L,1),1);
    for i=1:length(ids)
        D = sqrt(sum((SA(:,1:2) - L(i,:)).^2,2));
        I = D < SA(:,3);
        if sum(I) > 0
            ids(i) = 1;
        end
    end
end

function M = center(M)
    for i=1:size(M,2)
        mean = sum(M(:,i))/size(M,1);
        v = sqrt(var(M(:,i)));
        M(:,i) = (M(:,i)-mean)/v;
    end
end

function [R,A] = eval_area(T1,T2,L,SA,tau,X1,X2)
    %Diff of areas found, diff of areas not found, quantile diff of areas found.
    A=zeros(size(SA,1),2);
    f_ids = zeros(size(SA,1),1);
    for i=1:size(SA,1)
        D = sqrt(sum((L-SA(i,1:2)).^2,2));
        ids = D <= SA(i,3);
        f_ids(ids==1) = 1;
        
        A(i,1) = sum(abs(T2(ids)-T1(ids)))/sum(ids);
        A(i,2) = abs(quantile(T2(ids),tau)-quantile(T1(ids),tau));
    end
    td = sum(A(:,1))/size(SA,1);
    qd = sum(A(:,2))/size(SA,1);
    fd = sum(abs(T2(f_ids==0)-T1(f_ids==0)))/sum(~f_ids);
    alt = sum(abs(T2(f_ids==1)-T1(f_ids==1)))/sum(f_ids);
    R = [td;alt;fd;qd];
end