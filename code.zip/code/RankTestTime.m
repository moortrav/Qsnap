function [max_t,loc,PS,b_ids] = RankTestTime(X1,Y1,L1,X2,Y2,L2,tau,Gu,Gs,ms,min_size)
    min_size = min_size / 2;
    alpha = .01;
    max_size = min(ms,length(Y2));
    X = [X1;X2];
    Y = [Y1;Y2];
    L = [L1;L2];
    I = [ones(length(Y1),1);2*ones(length(Y2),1)];
    
    PS = [];
    
    SA = zeros(0,size(L,2)+3);
    loc = zeros(1,size(L,2)+1);
    
    [beta,hid] = qrsimplex(X,Y,tau);
    
    %setup start locations
    c_num = 20;
    max_d = max(L,[],1);
    min_d = min(L,[],1);
    C = zeros(c_num^length(max_d),length(max_d));
    for i=1:c_num
        range = ((i-1)*c_num+1):(i*c_num);
        C(range,:) = [(1:c_num)',ones(c_num,1)*i];
    end
    C = C .* (max_d-min_d)/c_num;
    C = C + min_d;
    
    %Do spatial search for different start points
    max_t = 0;
    for i=1:size(C,1)
        start = C(i,:);
        D = sqrt(sum((L-start).^2,2));
        [d,s] = sort(D);
        if d(1) > .5
            continue;
        end
        num1=0;
        num2=0;
        val = 0;
        while(num1 < min_size || num2 < min_size)
            val = val+1;
            if(I(s(val)) == 1)
                num1 = num1+1;
            else
                num2 = num2+1;
            end
        end
        ids = [I(s),s];
        ids = ids(1:max_size,:);
        if val < max_size
            [t,id,ts] = TimeLoop(X,Y,ids,beta,tau,hid,val);
            dist = D(ids(ts(:,1),2));
            ps = chi2cdf(ts(:,2),size(X,2),'upper');
            S = zeros(length(dist),2);
            for f=1:length(dist)
                S(f,:) = start;
            end
            PS = [PS;[S,dist,ps]];
        else
            t = 0;
        end
        if t>max_t
            max_t = t;
            radius = max(D(ids(1:id,2)));
            loc = [start,radius];
            b_ids = ids(1:id,2);
        end
        p = evcdf(-t,-Gu,Gs);
        if p < alpha
            radius = max(D(ids(1:id,2)));
            hs = [start,radius,p,t];
            SA = [SA;hs];
            
        end
    end
    %c_ids = c_ids - length(Y1);
    [d,id] = sort(SA(:,end),'descend');
    SA = SA(id,:);
    
    [d,id] = sort(PS(:,end));
    PS = PS(id,:);
    bonfer = 1;
    if bonfer == 1
        bon = alpha/size(PS,1);
        PS = PS(PS(:,4)<bon,:);
    else
        K = (1:size(PS,1))*alpha/size(PS,1);
        C = 1./(1:size(PS,1));
        for i=2:length(C)
            C(i) = C(i)+C(i-1);
        end
        for i=size(PS,1):-1:1
            if PS(i,4) <= K(i)/C(i)%alpha/(size(PS,1)-i+1)%
                PS = PS(1:i,:);
                break;
            end
        end
    end
    if size(PS,1)>0
        PS = sortrows(PS,[1,2,3]);
    end
    nPS = [];
    for i=1:size(PS,1)
        if i==size(PS,1)
            nPS = [nPS;PS(i,:)];
            break;
        end
        if sum(PS(i,1:2)==PS(i+1,1:2)) < 2
            nPS = [nPS;PS(i,:)];
        end
    end
    PS = nPS;
    if size(PS,1)>0
        PS = sortrows(PS,4);
    end
    %Conv hull idea
    %[p_ids,max_t] = convHullSearch(L,X,Y,I,beta,tau,hid,min_size,TS,max_size);
end

%**Appears to be working
%X,Y have all data points.  ids(:,1) says which time slice they come from.
%ids is an nx2 matrix.  First column is 1 or 2, indicating which X set
%min_size is calculated so that that point in ids will have enough points
%in X2 and outside of X2.
function [best_t,best_id,TS] = TimeLoop(X,Y,ids,beta,tau,hid,min_size)
    best_t = 0;
    best_id = 0;
    p = size(X,2);
    
    TS = zeros(size(ids,1)-min_size+1,2);

    %Initiatize null Qh and Rh
    [Qh,Rh] = qr(X(ids(p:-1:1,2),:));
    %Initialize null Qz and Rz
    X2 = X(ids(p:-1:1,2),:);
    X2(ids(p:-1:1,1) == 1,:) = zeros(sum(ids(p:-1:1,1)==1),p);
    Z = X2-Qh*(Qh'*X2);
    [Qz,Rz] = qr(Z);
    

    %Update QRh and QRz through min_size
    for i=(p+1):(min_size-1)
        x = X(ids(i,2),:);
        v = x;
        if ids(i,1) == 1
            v = zeros(size(x));
        end
        [Qh,Rh,u] = qrRow(Qh,Rh,x);
        [Qz,Rz] = qrRow(Qz,Rz,x*0);
        X2 = [v;X2];
        g = u'*X2;
        [Qz,Rz] = qrup(Qz,Rz,u,g');
    end
    %fit initial beta and b
    Xc = X(ids((min_size-1):-1:1,2),:);
    Yc = Y(ids((min_size-1):-1:1,2));
    [beta,hid] = qrsimplex(Xc,Yc,tau);
    %b=RankValues(Xc,Yc,beta,tau);
    
    %Incrementally calculate T
    del2 = zeros(size(X,2),1);
    for i=min_size:size(ids,1)
        %Update QRh and QRz
        x = X(ids(i,2),:);
        v = x;
        if ids(i,1) == 1
            v = zeros(size(x));
        end
        [Qh,Rh,u] = qrRow(Qh,Rh,x);
        [Qz,Rz] = qrRow(Qz,Rz,v*0);
        X2 = [v;X2];
        g = u'*X2;
        [Qz,Rz] = qrup(Qz,Rz,u,g');
        
        %Update beta and rank vector
        Xc = X(ids(i:-1:1,2),:);
        Yc = Y(ids(i:-1:1,2));
        
        [beta,hid,d] = qrsimplex(Xc,Yc,tau,beta,hid+1);
        beta_alt = qrsimplex([Xc,X2],Yc,tau);
        p = size(X2,2);
        %beta_diff = beta_alt((p+1):end)-beta;
        beta_diff = beta_alt((p+1):end);
        
        %Faster rank value update
        b = zeros(size(Yc));
        b(Yc - Xc*beta > 0) = 1;
        b(hid) = d+(1-tau);
        
        %Calculate T
        U = b'*Qz;
        T = U*U';
        T = T/(tau*(1-tau));
        
        %One sided test
        %U = Rz\(Qz'*b)*sqrt(i)/(tau*(1-tau));
        %ht = -ones(size(X,2),1);
        %ht = [1;1;1;1];
        %if(canSkip(U,ht) ~= 1)
        %    del = OptimizeSolve(del2,Rz,U,ht);
        %    del_alt = Opt2(Rz,U,ht);
        %    T = T - sum((Rz*del_alt).^2)*tau*(1-tau)/i;
        %end
        if T > 80
            flag=1;
        end
        
        TS(i-min_size+1,:) = [i,T];
        Told = T;
        if T > best_t
            best_t = T;
            best_id = i;
        end
    end
end

%Works as intended
function [Q,R,u] = qrRow(Q,R,v)
    R = [v;R];
    Q = [zeros(size(Q,1),1),Q];
    Q = [zeros(1,size(Q,2));Q];
    Q(1,1) = 1;
    
    for i=1:size(R,2)
        [c,s] = givens(R(i,i),R(i+1,i));
        R([i,i+1],i:end) = [c,-s;s,c] * R([i,i+1],i:end);
        Q(:,[i,i+1]) = Q(:,[i,i+1])*[c,s;-s,c];
    end
    u = Q(:,end);
    R = R(1:(end-1),:);
    Q = Q(:,1:(end-1));
end

%Compute givens rotation values
function [c,s] = givens(a,b)
    if b==0
        c=1;
        s=0;
    else
        if abs(b) > abs(a)
            t = -a/b;
            s = 1/sqrt(1+t^2);
            c = s*t;
        else
            t = -b/a;
            c = 1/sqrt(1+t^2);
            s = c*t;
        end
    end
end

function v = canSkip(U,ht)
    v = 1;
    for i = 1:length(ht)
        if ht(i) < 0 && U(i) > 0
            v = 0;
            break;
        end
        if ht(i) > 0 && U(i) < 0
            v = 0;
            break;
        end
    end
end

function x = Opt2(R,u,ht)
    %****Verify A = R'R mathematically
    A = double(R'*R);%zeros(size(R));
    
    lb = -Inf*ones(size(u));
    ub = Inf*ones(size(u));
    for i=1:length(u)
        if ht == 1
            ub(i) = u(i);
        end
        if ht == -1
            lb(i) = u(i);
        end
    end
    x = lsqlin(A,zeros(size(u)),[],[],[],[],lb,ub);
    %x((ht == 1) & (x > u)) = u((ht == 1) & (x > u));
    %x((ht == -1) & (x < u)) = u((ht == -1) & (x < u));
end

%ht is a p vector, each entry defines the hypothesis test for that
%parameter.
%  0: Either direction
%  1: Strictly greater
% -1: Strictly less
function [x] = OptimizeSolve(x,R,u,ht)
    eps = .001;
    diff = 1;
    alpha = .9;
    iter = 1;
    max_iter = 100;
    g2 = zeros(size(x));
    for i=1:length(x)
        for j = 1:i
            g2(i) = g2(i) + 2*R(j,i)^2;
        end
    end
    while(diff > eps && iter <= max_iter)
        %Calculate gradient
        r = R*x;
        g = zeros(size(x));
        for i=1:length(x)
            for j = 1:i
                g(i) = g(i)+2*r(j)*R(j,i);
            end
        end
        xn = x-g./g2;
        xn((ht == 1) & (xn > u)) = u((ht == 1) & (xn > u));
        xn((ht == -1) & (xn < u)) = u((ht == -1) & (xn < u));
        diff = sum((xn-x).^2);
        val = xn'*R'*R*xn;
        %diff = abs(xn'*R*R'*xn - x'*R*R'*x);
        x = xn;
        alpha = alpha*.99;
        iter = iter+1;
    end
end

function [p_ids,max_t] = convHullSearch(L,X,Y,I_ids,beta,tau,hid,min_size,TS,max_size)
    [VS,tids] = sort(TS,'descend');
    
    inside = zeros(size(Y));
    I = 1:length(Y);
    l_ids = [];
    for i=3:max_size
        %Calculate current convex hull
        K = convhull(L(tids(1:i),:));
        K = L(tids(K),:);
        
        %Determine new points that have entered the hull
        new_points = false(size(Y));
        new_points(inside==0) = inpolygon(L(inside==0,1),L(inside==0,2),K(:,1),K(:,2));
        n_ids = I(new_points);
        inside(n_ids) = 1;
        
        %Add points to list
        l_ids = [l_ids,n_ids];
        %If past maximum size, stop
        if length(l_ids) > max_size
            break;
        end
    end
    
    ids = [I_ids(l_ids),l_ids'];
    
    %Calculate val, where to start
    num1=0;
    num2=0;
    val = 0;
    while(num1 < min_size || num2 < min_size)
        val = val+1;
        if(ids(val,1) == 1)
            num1 = num1+1;
        else
            num2 = num2+1;
        end
    end
    
    [max_t,id,TS] = TimeLoop(X,Y,ids,beta,tau,hid,val,TS);
    p_ids = l_ids(1:id);
end