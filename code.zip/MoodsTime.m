%SSS-Moods scan algorithm
%INPUTS:
%X1 - Covariates from snapshot 1
%Y1 - Responses from snapshot 1
%L1 - Locations from snapshot 1
%X2, Y2, L2 - Covariates, responses, and locations from snapshot 2
%tau - quantile to compare, [0,1]
%Gu, Gs - Parameters for gumbel distribution for p-value correction
%ms - Maximum region size
function [max_t,loc,SA] = MoodsTime(X1,Y1,L1,X2,Y2,L2,tau,Gu,Gs,ms)
    alpha = .05;
    min_size = 20;
    max_size = min(ms,length(Y2));
    X = [X1;X2];
    Y = [Y1;Y2];
    L = [L1;L2];
    I = [ones(length(Y1),1);2*ones(length(Y2),1)];
    
    SA = zeros(0,size(L,2)+2);
    loc = zeros(1,size(L,2)+1);
    
    %[beta,hid] = qrsimplex(X,Y,tau);
    
    %setup start locations
    c_num = 10;
    max_d = max(L,[],1);
    min_d = min(L,[],1);
    C = zeros(c_num^length(max_d),length(max_d));
    for i=1:c_num
        range = ((i-1)*c_num+1):(i*c_num);
        C(range,:) = [(1:c_num)',ones(c_num,1)*i];
    end
    C = C .* (max_d-min_d)/c_num;
    C = C + min_d;
    
    %Do spatial search for different start points
    max_t = 0;
    for i=1:size(C,1)
        start = C(i,:);
        D = sqrt(sum((L-start).^2,2));
        [d,s] = sort(D);
        num1=0;
        num2=0;
        val = 0;
        while(num1 < min_size || num2 < min_size)
            val = val+1;
            if(I(s(val)) == 1)
                num1 = num1+1;
            else
                num2 = num2+1;
            end
        end
        ids = [I(s),s];
        ids = ids(1:max_size,:);
        if val < max_size
            [t,id] = MoodsLoop(X,Y,ids,tau,val);
        else
            t = 0;
        end
        if t>max_t
            max_t = t;
            radius = max(D(ids(1:id,2)));
            loc = [start,radius];
        end
        p = evcdf(-t,-Gu,Gs);
        if p < alpha
            radius = max(D(ids(1:id,2)));
            hs = [start,radius,p];
            SA = [SA;hs];
            
        end
    end
    %c_ids = c_ids - length(Y1);
    [d,id] = sort(SA(:,end));
    SA = SA(id,:);
end

function [bestt,bestid] = MoodsLoop(X,Y,ids,tau,min_size)
    bestt=0;
    bestid=0;
    %Create initial data split
    X1 = X(ids(1:(min_size-1),2),:);
    X1 = X1(ids(1:(min_size-1),1)==1,:);
    Y1 = Y(ids(1:(min_size-1),2));
    Y1 = Y1(ids(1:(min_size-1),1)==1);
    
    [beta,hid] = qrsimplex(X1,Y1,tau);
    
    %Expand region, recalculate MoodsTest
    for i=min_size:size(ids,1)
        if ids(i,1) == 1
            X1 = [X1;X(ids(i,2),:)];
            Y1 = [Y1;Y(ids(i,2))];
            [beta,hid] = qrsimplex(X1,Y1,tau,beta,hid);
        end
        %Assemble T table
        T = zeros(2,2);
        D = Y(ids(1:i,2)) - X(ids(1:i,2),:)*beta;
        D = round(sign(D)/2+1.5);
        for j=1:length(D)
            T(ids(j,1),D(j)) = T(ids(j,1),D(j))+1;
        end
        %calculate test value
        [~,~,t] = chi2cont(T);
        if t > bestt
            bestt = t;
            bestid = i;
        end
    end
end